Instructions to run:
* Navigate to directory
* > make
* ./multi-lookup input1.txt input2.txt result.txt (last file is the output)
* Enjoy!